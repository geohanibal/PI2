package de.uni_bremen.pi2;

import java.util.Comparator;

/**
 * Implementierung verschiedener Suchverfahren.
 * @author Thomas Röfer
 */
public class Search
{
    /**
     * Lineare Suche nach einem Schlüsselwert.
     * @param a Das Array, das durchsucht wird.
     * @param key Der Schlüssel, nach dem gesucht wird.
     * @return Der Index der ersten Fundstelle des Schlüssels im Array.
     *         -1, wenn der Schlüssel nicht gefunden wurde.
     */
    public static int linearSearch(final Object[] a, final Object key)
    {
        print(a);
        int i = 0;
        while (i < a.length && !a[i].equals(key)) {
            print("" + key, i);
            ++i;
        }
        print("" + key, i);
        return i == a.length ? -1 : i;
    }

    /**
     * Binäre Suche nach einem Schlüsselwert.
     * @param a Das Array, das durchsucht wird. Es muss nach der natürlichen
     *          Ordnung des Elementtyps sortiert sein.
     * @param key Der Schlüssel, nach dem gesucht wird.
     * @return Der Index einer Fundstelle des Schlüssels im Array.
     *         -1, wenn der Schlüssel nicht gefunden wurde.
     */
    public static <T extends Comparable<T>> int binarySearch(final T[] a, final T key)
    {
        print(a);
        if (a.length == 0) {
            return -1;
        }
        else {
            int bottom = 0;
            int top = a.length;
            while (bottom + 1 != top) {
                final int mid = bottom + (top - bottom) / 2;
                print(">" + key + "<", bottom, mid, top);
                if (a[mid].compareTo(key) > 0) {
                    top = mid;
                }
                else {
                    bottom = mid;
                }
            }
            print("" + key, bottom);
            return a[bottom].compareTo(key) == 0 ? bottom : -1;
        }
    }

    /**
     * Binäre Suche nach einem Schlüsselwert mit Comparator.
     * @param a Das Array, das durchsucht wird. Es muss in der durch
     *          den Comparator definierten Ordnung sortiert sein.
     * @param key Der Schlüssel, nach dem gesucht wird.
     * @param c Der Comparator, nach dessen Ordnung das Array sortiert
     *          sein muss.
     * @return Der Index einer Fundstelle des Schlüssels im Array.
     *         -1, wenn der Schlüssel nicht gefunden wurde.
     */
    public static <T> int binarySearch(final T[] a, final T key, final Comparator<T> c)
    {
        print(a);
        if (a.length == 0) {
            return -1;
        }
        else {
            int bottom = 0;
            int top = a.length;
            while (bottom + 1 != top) {
                final int mid = bottom + (top - bottom) / 2;
                print(">" + key + "<", bottom, mid, top);
                if (c.compare(a[mid], key) > 0) {
                    top = mid;
                }
                else {
                    bottom = mid;
                }
            }
            print("" + key, bottom);
            return c.compare(a[bottom], key) == 0
                    ? bottom : -1;
        }
    }

    /**
     * Binäre Suche nach einem Schlüsselwert mit frühem Abbruch.
     * @param a Das Array, das durchsucht wird. Es muss nach der natürlichen
     *          Ordnung des Elementtyps sortiert sein.
     * @param key Der Schlüssel, nach dem gesucht wird.
     * @return Der Index einer Fundstelle des Schlüssels im Array.
     *         -1, wenn der Schlüssel nicht gefunden wurde.
     */
    public static <T extends Comparable<T>> int binarySearchEarly(final T[] a, final T key)
    {
        print(a);
        int bottom = 0;
        int top = a.length;
        while (bottom != top) {
            final int mid = bottom + (top - bottom) / 2;
            print(">" + key + "<", bottom, mid, top);
            final int comp = a[mid].compareTo(key);
            if (comp == 0) {
                print("" + key, mid);
                return mid;
            }
            else if (comp > 0) {
                top = mid;
            }
            else {
                bottom = mid + 1;
            }
        }
        return -1;
    }

    /**
     * Interpolationssuche nach einem Schlüsselwert.
     * @param a Das Array, das durchsucht wird. Es muss nach der natürlichen
     *          Ordnung des Elementtyps sortiert sein.
     * @param key Der Schlüssel, nach dem gesucht wird.
     * @return Der Index einer Fundstelle des Schlüssels im Array.
     *         -1, wenn der Schlüssel nicht gefunden wurde.
     */
    public static <T extends Number & Comparable<T>> int interpolationSearch(final T[] a, final T key)
    {
        print(a);
        int bottom = 0;
        int top = a.length - 1;
        if (a[bottom].compareTo(key) <= 0 && a[top].compareTo(key) >= 0) {
            while (bottom < top) {
                final int mid = bottom +
                        (int) ((key.doubleValue() - a[bottom].doubleValue())
                                / (a[top].doubleValue() - a[bottom].doubleValue()) * (top - bottom));
                print(">" + key + "<", bottom, mid, top);
                final int comp = a[mid].compareTo(key);
                if (comp == 0) {
                    print("" + key, mid);
                    return mid;
                } else if (comp > 0) {
                    top = mid - 1;
                } else {
                    bottom = mid + 1;
                }
            }
        }
        print("" + key, bottom);
        return -1;
    }

    /**
     * Bestimmt die Levenshtein-Distanz zwischen zwei Zeichenketten.
     * @param src Die eine Zeichenkette.
     * @param dest Die andere Zeichenkette.
     * @return Die Editierdistanz.
     */
    public static int editDistance(final String src, final String dest)
    {
        final int[][] table = new int[src.length() + 1][dest.length() + 1];
        for (int i = 0; i <= src.length(); ++i) {
            for (int j = 0; j <= dest.length(); ++j) {
                table[i][j] = i == 0 ? j
                        : j == 0 ? i
                        : src.charAt(i - 1) == dest.charAt(j - 1) ? table[i - 1][j - 1]
                        : 1 + Math.min(table[i - 1][j - 1],
                        Math.min(table[i][j - 1],
                                table[i - 1][j]));
            }
        }
        return table[src.length()][dest.length()];
    }

    /**
     * Gibt alle Elemente eines Arrays durch Leerzeichen getrennt als Zeile aus.
     * @param a Das Array, das ausgegeben wird.
     */
    private static void print(final Object[] a)
    {
        for (final Object o : a) {
            System.out.print(o + " ");
        }
        System.out.println();
    }

    /**
     * Gibt Symbole in bestimmten Spalten aus.
     * @param symbols Die Symbole.
     * @param columns Die Spaltennummern. Ihre Anzahl muss gleich der Anzahl der Symbole
     *                sein. Die Nummern müssen aufsteigend sortiert sein und müssen sich
     *                unterscheiden.
     */
    private static void print(String symbols, final Integer... columns)
    {
        int prevColumn = 0;
        for (final int column : columns) {
            if(column >= prevColumn) {
                System.out.print(" ".repeat((column - prevColumn) * 2) + symbols.charAt(0) + " ");
            }
            prevColumn = column + 1;
            symbols = symbols.substring(1);
        }
        System.out.println();
    }
}
