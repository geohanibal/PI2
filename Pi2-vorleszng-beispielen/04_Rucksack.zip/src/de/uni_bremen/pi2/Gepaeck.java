package de.uni_bremen.pi2;

/**
 * Ein Gepäckstück für das Rucksackproblem.
 * @param gewicht Das Gewicht des Gepäckstücks.
 * @param wert Der Wert (d.h. die Nützlichkeit) des Gepäckstücks.
 * @author Thomas Röfer
 */
public record Gepaeck(int gewicht, int wert)
{
}
