package de.uni_bremen.pi2;

public class PartielleKorrektheit
{
    /**
     * Die Methode berechnet die Fakultät der Eingabe.
     * @param n Die Zahl, deren Fakultät berechnet wird. Muss mindestens 0 sein.
     * @return Die Fakultät von n, wenn sich diese mit dem Wertebereich von int
     *         darstellen lässt. Ansonsten ist das Ergebnis undefiniert.
     */
    public static int fakultät(final int n)
    {
        // {n >= 0}
        // {n >= 0 & 1 = 1}
        int f = 1;
        // {n >= 0 & f = 1}
        // {n >= 0 & f = 1 & 1 = 1}
        int i = 1;
        // {n >= 0 & f = 1 & i = 1}
        // {i <= n + 1 & f = (i - 1)!}
        while (i <= n) {
            // {i <= n + 1 & f = (i - 1)! & i <= n}
            // {i <= n & f = (i - 1)!}
            // {i <= n & f * i = (i - 1)! * i}
            // {i <= n & f * i = i!}
            f = f * i;
            // {i <= n & f = i!}
            // {i + 1 <= n + 1 & f = (i + 1 - 1)!}
            i = i + 1;
            // {i <= n + 1 & f = (i - 1)!}
        }
        // {i <= n + 1 & f = (i - 1)! & ~(i <= n)}
        // {i = n + 1 & f = (i - 1)!}
        // {f = (n + 1 - 1)!}
        // {f = n!}
        return f;
    }
}
