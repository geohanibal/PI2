package de.uni_bremen.pi2;

public class Terminierung
{
    /**
     * Die Methode berechnet die Fakultät der Eingabe.
     * @param n Die Zahl, deren Fakultät berechnet wird. Muss mindestens 0 sein.
     * @return Die Fakultät von n, wenn sich diese mit dem Wertebereich von int
     *         darstellen lässt. Ansonsten ist das Ergebnis undefiniert.
     */
    public static int fakultät(final int n)
    {
        int f = 1;
        int i = 1;
        // Invariante: i <= n + 1 & f = (i - 1)!
        // Variante: t = n + 1 - i, t >= 0
        while (i <= n) {
            // {n + 1 - i = z & i <= n}
            // {n - i < z}
            f = f * i;
            // {n - i < z}
            // {n + 1 - (i + 1) < z}
            i = i + 1;
            // {n + 1 - i < z}
        }
        return f;
    }
}
