package de.uni_bremen.pi2;

/**
 * Beschränkte Warteschlage (first-in, first-out).
 * @param <E> Der Typ der Werte, die in der Warteschlange gespeichert werden
 *         können.
 */
public class Queue<E>
{
    /** Die gespeicherten Werte. */
    private final E[] values;

    /** Der Index des Elements, das als nächstes entnommen würde. */
    private int first = 0;

    /** Die Anzahl der Werte im Stapel. */
    private int size = 0;

    /**
     * Konstruktor für eine leere Warteschlange.
     * @param capacity Die Maximalkapazität der Warteschlange.
     */
    @SuppressWarnings("unchecked")
    public Queue(final int capacity)
    {
        values = (E[]) new Object[capacity];
    }

    /**
     * Ist die Warteschlange leer?
     * @return Ist er leer?
     */
    public boolean empty()
    {
        return size == 0;
    }

    /**
     * Anhängen eines Werts an die Warteschlange.
     * @param value Der Wert, der abgehängt wird.
     * @throws IllegalStateException Die Warteschlange ist bereits voll.
     */
    public void push(final E value)
    {
        if (size < values.length) {
            values[(first + size++) % values.length] = value;
        }
        else {
            throw new IllegalStateException("Die Warteschlange ist bereits voll");
        }
    }

    /**
     * Entnehmen des nächsten Werts aus der Warteschlange.
     * @return Der nächste Wert.
     * @throws IllegalStateException Die Warteschlange war bereits leer.
     */
    public E pop()
    {
        final E value = top();
        --size;
        first = (first + 1) % values.length;
        return value;
    }

    /**
     * Liefern des nächsten Werts aus der Warteschlange. Dieser verbleibt
     * auf in der Warteschlange.
     * @return Der nächste Wert.
     * @throws IllegalStateException Die Warteschlange ist leer.
     */
    public E top()
    {
        if (size > 0) {
            return values[first];
        }
        else {
            throw new IllegalStateException("Die Warteschlange ist leer");
        }
    }

    /**
     * Liefern des Inhalts der Warteschlange als Zeichenkette.
     * @return Der Inhalt als String.
     */
    @Override
    public String toString()
    {
        final StringBuilder result = new StringBuilder("[");
        String separator = "";
        for (int i = 0; i < size; ++i) {
            result.append(separator).append(values[(first + i) % values.length]);
            separator = ", ";
        }
        return result.append("]").toString();
    }
}