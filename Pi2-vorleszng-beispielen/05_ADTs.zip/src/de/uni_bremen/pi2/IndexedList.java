package de.uni_bremen.pi2;

/**
 * Eine einfach verkettete Liste, die per Index adressiert werden kann.
 * @param <E> Der Typ der Werte, die in der Liste gespeichert werden können.
 */
public class IndexedList<E>
{
    /** Der Knoten mit dem ersten Wert der Liste. Wenn null, ist die Liste leer. */
    private SLNode<E> first = null;

    /** Die Anzahl der Werte in der Liste. */
    private int size = 0;

    /**
     * Gibt die Anzahl der Werte in der Liste zurück.
     * @return Die Größe der Liste.
     */
    public int size()
    {
        return size;
    }

    /**
     * Liefern eines Werts aus der Liste.
     * @param index Der Index des Werts.
     * @return Der Wert.
     * @throws IllegalArgumentException Der angegebene Index ist ungültig.
     */
    public E get(final int index)
    {
        checkIndex(index, size);
        return at(index).value;
    }

    /**
     * Setzen eines Werts in der Liste.
     * @param index Der Index, an den der Wert geschrieben werden soll.
     * @param value Der Wert.
     * @throws IllegalArgumentException Der angegebene Index ist ungültig.
     */
    public void set(final int index, final E value)
    {
        checkIndex(index, size);
        at(index).value = value;
    }

    /**
     * Einfügen eines Werts in die Liste.
     * @param index Der Index, an dem der Wert eingefügt werden soll. Ist der
     *         Index gleich der Größe, wird angehängt.
     * @param value Der Wert.
     * @throws IllegalArgumentException Der angegebene Index ist ungültig.
     */
    public void insert(final int index, final E value)
    {
        checkIndex(index, size + 1);
        if (index == 0) {
            first = new SLNode<>(value, first);
        }
        else {
            final SLNode<E> current = at(index - 1);
            current.next = new SLNode<>(value, current.next);
        }
        ++size;
    }

    /**
     * Löschen eines Werts aus der Liste.
     * @param index Der Index, an dem ein Wert gelöscht werden soll.
     * @throws IllegalArgumentException Der angegebene Index ist ist ungültig.
     */
    public void remove(final int index)
    {
        checkIndex(index, size);
        if (index == 0) {
            first = first.next;
        }
        else {
            SLNode<E> current = at(index - 1);
            current.next = current.next.next;
        }
        --size;
    }

    /**
     * Liefert den Knoten mit einem bestimmten Index.
     * @param index Der Index des gesuchten Knotens. Muss gültig sein.
     * @return Den Knoten zum Index.
     */
    private SLNode<E> at(final int index)
    {
        SLNode<E> current = first;
        for (int i = 0; i < index && current != null; ++i) {
            current = current.next;
        }
        return current;
    }

    /**
     * Überprüft die Gültigkeit des Indexes.
     * @param index Der zu überprüfenden Index.
     * @param size Die gültige Obergrenze (exklusiv).
     * @throws IllegalArgumentException Der Index ist ungültig.
     */
    private void checkIndex(final int index, final int size)
    {
        if (index < 0 || index >= size) {
            throw new IllegalArgumentException("Index " + index + " ist ungültig");
        }
    }

    /**
     * Liefert eine Zeichenkette mit dem Inhalt der Liste.
     * @return Der Inhalt als String.
     */
    @Override
    public String toString()
    {
        final StringBuilder result = new StringBuilder("[");
        String separator = "";
        for (SLNode<E> current = first; current != null; current = current.next) {
            result.append(separator).append(current);
            separator = ", ";
        }
        return result.append("]").toString();
    }
}
