package de.uni_bremen.pi2;

/**
 * Beschränkter Stapel (last-in, first-out).
 * @param <E> Der Typ der Werte, die im Stapel gespeichert werden können.
 */
public class Stack<E>
{
    /** Die gespeicherten Werte. */
    private final E[] values;

    /** Die Anzahl der Werte im Stapel. */
    private int size = 0;

    /**
     * Konstruktor für einen leeren Stapel.
     * @param capacity Die Maximalkapazität des Stapels.
     */
    @SuppressWarnings("unchecked")
    public Stack(final int capacity)
    {
        values = (E[]) new Object[capacity];
    }

    /**
     * Ist der Stapel leer?
     * @return Ist er leer?
     */
    public boolean empty()
    {
        return size == 0;
    }

    /**
     * Ablegen eines Werts oben auf den Stapel.
     * @param value Der Wert, der abgelegt wird.
     * @throws IllegalStateException Der Stapel ist bereits voll.
     */
    public void push(final E value)
    {
        if (size < values.length) {
            values[size++] = value;
        }
        else {
            throw new IllegalStateException("Der Stapel ist bereits voll");
        }
    }

    /**
     * Entnehmen des obersten Werts vom Stapel.
     * @return Der oberste Wert.
     * @throws IllegalStateException Der Stapel war bereits leer.
     */
    public E pop()
    {
        final E value = top();
        --size;
        return value;
    }

    /**
     * Liefern des obersten Werts auf dem Stapel. Dieser verbleibt auf
     * dem Stapel.
     * @return Der oberste Wert.
     * @throws IllegalStateException Der Stapel ist leer.
     */
    public E top()
    {
        if (size > 0) {
            return values[size - 1];
        }
        else {
            throw new IllegalStateException("Der Stapel ist leer");
        }
    }

    /**
     * Liefern des Inhalts des Stapels als Zeichenkette.
     * @return Der Inhalt als String.
     */
    @Override
    public String toString()
    {
        final StringBuilder result = new StringBuilder("[");
        String separator = "";
        for (int i = 0; i < size; ++i) {
            result.append(separator).append(values[i]);
            separator = ", ";
        }
        return result.append("]").toString();
    }
}