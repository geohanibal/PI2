package de.uni_bremen.pi2;

/**
 * Die Klasse repräsentiert einen Knoten in einer doppelt verketteten Liste.
 * Der Knoten besteht aus einem gespeicherten Wert und einer Referenz auf das
 * nächste Element der Liste.
 * @param <E> Der Typ der Werte, die in der Liste gespeichert werden können.
 */
public class DLNode<E>
{
    /** Der gespeicherte Wert. */
    final E value;

    /**
     * Der Knoten mit dem vorherigen Element der Liste oder null, wenn dieser der
     * erste ist.
     */
    DLNode<E> previous;

    /**
     * Der Knoten mit dem nächsten Element der Liste oder null, wenn dieser der
     * letzte ist.
     */
    DLNode<E> next;

    /**
     * Konstruktor eines Knotens.
     * @param value Der gespeicherte Wert.
     * @param previous Der Knoten mit dem vorherigen Element der Liste oder null, wenn
     *         dieser der erste ist.
     * @param next Der Knoten mit dem nächsten Element der Liste oder null, wenn
     *         dieser der letzte ist.
     */
    DLNode(final E value, final DLNode<E> previous, final DLNode<E> next)
    {
        this.value = value;
        this.previous = previous;
        this.next = next;
    }

    /**
     * Liefert eine Zeichenkette mit dem in diesem Knoten gespeicherten Wert.
     * @return Der Wert als String.
     */
    @Override
    public String toString()
    {
        return value.toString();
    }
}
