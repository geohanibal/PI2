package de.uni_bremen.pi2;

/**
 * Eine doppelt verkettete Ringliste.
 * Es gibt einen Basisknoten, der keinen Wert speichert und gleichzeitig als
 * Anfang und Ende der Liste fungiert.
 * @param <E> Der Typ der Werte, die in der Liste gespeichert werden können.
 */
public class DLRList<E>
{
    /** Der Basisknoten des Rings. Speichert keinen Wert. */
    private final DLNode<E> base = new DLNode<>(null, null, null);

    /**
     * Konstruktor. Initialisiert eine leere Liste.
     */
    public DLRList()
    {
        base.previous = base.next = base;
    }

    /**
     * Ist die Liste leer?
     * @return Ist sie leer?
     */
    public boolean empty()
    {
        assert (base.previous == base) == (base.next == base);
        return base.next == base;
    }

    /**
     * Einfügen eines Werts vor einem Knoten.
     * @param anchor Der Knoten, vor dem der neue Wert eingefügt wird.
     * @param value Der Wert, der eingefügt wird.
     */
    public DLNode<E> insert(DLNode<E> anchor, final E value)
    {
        // Am Ende ist vor dem Ring-Basisknoten.
        if (anchor == null) {
            anchor = base;
        }

        final DLNode<E> newNode = new DLNode<>(value, anchor.previous, anchor);
        anchor.previous = newNode;
        newNode.previous.next = newNode;
        return newNode;
    }

    /**
     * Löscht einen Knoten.
     * @param node Der Knoten, der gelöscht wird.
     */
    public void remove(final DLNode<E> node)
    {
        node.previous.next = node.next;
        node.next.previous = node.previous;
    }

    /**
     * Liefert eine Zeichenkette mit dem Inhalt der Liste.
     * @return Der Inhalt als String.
     */
    @Override
    public String toString()
    {
        final StringBuilder result = new StringBuilder("[");
        String separator = "";
        for (DLNode<E> current = base.next; current != base; current = current.next) {
            result.append(separator).append(current);
            separator = ", ";
        }
        return result.append("]").toString();
    }
}
