package de.uni_bremen.pi2;

/**
 * Eine einfach verkettete Liste.
 * @param <E> Der Typ der Werte, die in der Liste gespeichert werden können.
 */
public class SLList<E>
{
    /** Der Knoten mit dem ersten Wert der Liste. Wenn null, ist die Liste leer. */
    private SLNode<E> first = null;

    /**
     * Ist die Liste leer?
     * @return Ist sie leer?
     */
    public boolean empty()
    {
        return first == null;
    }

    /**
     * Einfügen eines Werts vor einem Knoten.
     * @param anchor Der Knoten, vor dem der neue Wert eingefügt wird. Ist dieser
     *         null, wird an das Ende der Liste angefügt.
     * @param value Der Wert, der eingefügt wird.
     * @throws IllegalArgumentException Der angegebene Knoten ist nicht Teil der
     *         Liste.
     */
    public SLNode<E> insert(final SLNode<E> anchor, final E value)
    {
        return insertAfter(previous(anchor), value);
    }

    /**
     * Einfügen eines Werts hinter einem Knoten.
     * @param anchor Der Knoten, nach dem eingefügt wird. Ist dieser null,
     *         wird am Anfang der Liste eingefügt.
     * @param value Der Wert, der eingefügt wird.
     */
    private SLNode<E> insertAfter(final SLNode<E> anchor, final E value)
    {
        if (anchor == null) {
            return first = new SLNode<>(value, first);
        }
        else {
            return anchor.next = new SLNode<>(value, anchor.next);
        }
    }

    /**
     * Löscht einen Knoten.
     * @param node Der Knoten, der gelöscht wird.
     * @throws IllegalArgumentException Der angegebene Knoten ist nicht Teil der
     *         Liste.
     */
    public void remove(final SLNode<E> node)
    {
        removeNext(previous(node));
    }

    /**
     * Löscht den Knoten, der auf den übergebenen Knoten folgt.
     * @param anchor Der Knoten, dessen Nachfolger entfernt wird. Ist dieser
     *         null, wird der erste Knoten entfernt.
     */
    private void removeNext(final SLNode<E> anchor)
    {
        if (anchor == null) {
            first = first.next;
        }
        else {
            anchor.next = anchor.next.next;
        }
    }

    /**
     * Bestimmt den Vorgänger eines Knotens.
     * @param anchor Der Knoten, dessen Vorgänger bestimmt wird (der Vorgänger
     *         von null ist der letzte Knoten der Liste).
     * @return Der Vorgängerknoten oder null, wenn anchor bereits der erste
     *         Knoten in der Liste ist.
     * @throws IllegalArgumentException Der angegebene Knoten ist nicht Teil der
     *         Liste.
     */
    private SLNode<E> previous(final SLNode<E> anchor)
    {
        try {
            if (first == anchor) {
                return null;
            }
            else {
                SLNode<E> current = first;
                while (current.next != anchor) {
                    current = current.next;
                }
                return current;
            }
        }
        catch (final NullPointerException e) {
            throw new IllegalArgumentException("Knoten ist nicht Teil der Liste");
        }
    }

    /**
     * Liefert eine Zeichenkette mit dem Inhalt der Liste.
     * @return Der Inhalt als String.
     */
    @Override
    public String toString()
    {
        final StringBuilder result = new StringBuilder("[");
        String separator = "";
        for (SLNode<E> current = first; current != null; current = current.next) {
            result.append(separator).append(current);
            separator = ", ";
        }
        return result.append("]").toString();
    }
}
