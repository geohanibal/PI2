package de.uni_bremen.pi2;

/**
 * Eine doppelt verkettete Liste.
 * @param <E> Der Typ der Werte, die in der Liste gespeichert werden können.
 */
public class DLList<E>
{
    /** Der Knoten mit dem ersten Wert der Liste. Wenn null, ist die Liste leer. */
    private DLNode<E> first = null;

    /** Der Knoten mit dem letzten Wert der Liste. Wenn null, ist die Liste leer. */
    private DLNode<E> last = null;

    /**
     * Ist die Liste leer?
     * @return Ist sie leer?
     */
    public boolean empty()
    {
        assert (first == null) == (last == null);
        return first == null;
    }

    /**
     * Einfügen eines Werts vor einem Knoten.
     * @param anchor Der Knoten, vor dem der neue Wert eingefügt wird. Ist dieser
     *         null, wird an das Ende der Liste angefügt.
     * @param value Der Wert, der eingefügt wird.
     */
    public DLNode<E> insert(final DLNode<E> anchor, final E value)
    {
        final DLNode<E> newNode;

        // Einfügen vor dem Ende?
        if (anchor == null) { // Ja
            newNode = new DLNode<>(value, last, null);
            last = newNode;
        }
        else { // Nein
            newNode = new DLNode<>(value, anchor.previous, anchor);
            anchor.previous = newNode;
        }

        // Einfügen am Anfang?
        if (newNode.previous == null) { // Ja
            first = newNode;
        }
        else { // Nein
            newNode.previous.next = newNode;
        }

        return newNode;
    }

    /**
     * Löscht einen Knoten.
     * @param node Der Knoten, der gelöscht wird.
     */
    public void remove(final DLNode<E> node)
    {
        // Löschen am Anfang?
        if (node.previous == null) { // Ja
            first = node.next;
        }
        else { // Nein
            node.previous.next = node.next;
        }

        // Löschen am Ende?
        if (node.next == null) { // Ja
            last = node.previous;
        }
        else { // Nein
            node.next.previous = node.previous;
        }
    }

    /**
     * Liefert eine Zeichenkette mit dem Inhalt der Liste.
     * @return Der Inhalt als String.
     */
    @Override
    public String toString()
    {
        final StringBuilder result = new StringBuilder("[");
        String separator = "";
        for (DLNode<E> current = first; current != null; current = current.next) {
            result.append(separator).append(current);
            separator = ", ";
        }
        return result.append("]").toString();
    }
}
